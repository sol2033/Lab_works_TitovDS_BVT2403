def multi(a,b):
  return a * b