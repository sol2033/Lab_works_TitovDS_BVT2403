def stringsum(a,b):
  return a + b