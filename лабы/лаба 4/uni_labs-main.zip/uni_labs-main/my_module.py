def summ(a,b):
    return a + b